v0.1.2

* fixed a bug where warhead strength is displayed incorrectly when radiation tech is available
* adjust the rounding in missile agility calculation so it should match the game better
* more logs added
* Force the jar to run in en_US locale to avoid number format issues


v0.1.1

* Slightly adjusted status bar position so it should not be hidden in half
* Force the jar to run in en_US locale if it is not already in to avoid number format issues

v0.1.0

An earlier version implemented in EXCEL can be found at
https://docs.google.com/spreadsheets/d/19djb0uS4AFqP94IeNRt5U_qbGrglI9Bz4iJEhcF5aRs/edit?usp=sharing
(download as EXCEL file as it runs slowly on Google sheets)

Currently only the missile optimizer is implemented.

The JAVA version keeps all previous features, and added the missile archive and the possibility to share a missile design.

The missile archive will be saved to a csv file automatically when shut down.

Double click on alternative missile design list/missile archive list loads the selected design for viewing.

Right click on missile archive brings up the menu to delete select entry.