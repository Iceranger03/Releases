v0.3.6

* improved the interface for the alternative missile result list and the missile archive list
	* now they are shown in tables
	* added right click menu to copy the design string
	* added right click menu to copy the missile name
* improved the tool tips for the above tables
* improved missile description string to contain second stage size
* improved missile auto naming to include ECM and ECCM if installed
* slightly adjust the formula in maneuver rating calculation
* speed related inputs in missile optimizer are limited to 299,000 kkm/s (in game missile speed limit). speed over this value will use this upper limit (and no warning on the UI)
* speed related inputs in ship optimizer are limited to 100,000 kkm/s (in game ship speed limit). similarly, speed over this value will use this upper limit (and no warning on the UI)
* ship tonnage is now no longer an int. this allows the ship optimizer to handle ships above 2,147,483,647 tons. but this does not necessarily mean you should design such ships :)
* related fix for ship planner to handle such large ships
* fixed a bug where ship and missile archives do not load long integer fields back correctly
* fixed a bug when canceling the 'save ship to archive' operation due to name conflict, the focus is not correctly returned to the ship name text box


v0.3.5

* more speed bands added in missile description
* fixed a bug where missiles with 2nd stages (reserved space) have their missile size displayed incorrectly
* missile auto naming now will not round missile sizes to integers


v0.3.4

* added a checkbox to filter out the civilian shipping company components when importing components from DB
	* by default civilian shipping company components are not imported
* added a button in ship planner, to toggle the total columns display in percentage on/off
	* in build up (Aurora) mode, total size is the current exact size
	* in fill up mode, total size is the planned ship size. in this mode, percentage can go above 100 when the ship is 'over filled'
* improved the tool tips shown in the ship planner component list and the component table
* improved the message box shown when importing DB without any player designed components
* fixed an issue when reading DB with multiple games/races with the same name
* when creating dummy sensor components, sensors less than 1HS are correctly labeled to be commercial components
* component import no longer reads missile engines (they are not displayed anyway)


v0.3.3

* new feature: sensor size planner on missile optimizer screen
	* calculates the minimum sensor and MFC size for the planned missile range
* ship planner now shows the correct armor type according to the armor tech used
* fixed a bug that when using the reload button, the number of engine/jump drive/cloaking device components keep growing in the component list
* fixed a bug where the engine power rating for plasma core anti matter tech was incorrect
* fixed a bug where the missile design parameters are not properly restored from config file when relaunching the app
* made warhead text box in missile optimizer only accepts non negative integers


v0.3.2

* new feature: added the ability to import player designed components from Aurora DB in ship planner
	* it should make the ship planner easier to use with the existing components
	* read only feature, won't change the DB in any way
* a check box was added to ship planner to link deployment time and maintenance life
* a button was added to ship planner to clear the current design, and reload from ship optimizer result
* add engineering button was replaced with auto engineering button, which now is able to add and remove engineering space from the design to match the desired maintenance life
* improved the readability of the text on the progress bar in the ship planner screen
* fixed a number formatting error in the missile description
* fixed a bug where the crew and cost calculation for commercial jump drive in ship planner screen was severely wrong


v0.3.1

* fixed a bug that allows crew quarters to be manually changed under some circumstances.


v0.3.0

* new feature: ship planner
* the ship planner takes the current design displayed in the ship optimizer window, and creates an environment similar to the Class Design window in the game
* when switch to the ship planner tab, the following components will be copied from the current ship design:
	* engines
	* fuel tanks
	* armor layers if included
	* jump drive if designed
	* cloaking device if designed
* other user added components already in the ship design table will not be modified.
* 2 modes of operation: build up mode and fill up mode
* build up mode is similar to the Class Design window, where the armor and maintenance are calculated based on the current exact size
* in the fill up mode, the armor and maintenance is calculated based on the planned ship size
* double click on the component list to add a component
* double click on a component in the ship component table to remove a component
* component number in ship design can be directly edited by double clicking on the count column.
* the amount of engine, jump drive, cloaking device and crew quarters cannot be directly edited from the table
* engine, jump drive, cloaking device can be changed by editing the corresponding fields in the ship optimizer screen
* the 'add engineering spaces' button can automatically add engineering space to achieve the desired maintenance life, based on the current components on the ship. it won't remove engineering spaces to reduce maintenance life.
* player designed components can be created by clicking on the 'add new component' entries in the component list under the corresponding component category
* this is not a full Class Designer, so only the size, crew number, and cost information of the player designed components are needed.
* currently, player designed components will not be saved between sessions
* crew quarters and bridge will be automatically added as in the game
* known limitation: deployment time cannot be reduced below 1, since the known formula does not match what's in the game
* known limitation: crew quarter allocation could be slightly different (larger) compared to in game, since currently in game (1.9.5), crew quarters can be a little bit under-sized.
* known limitation: auto engineering space button may add a few more engineering space than needed
* fixed a bug that causes missile engine tech not being loaded correctly from the saved values when starting the app


v0.2.3

* fixed a bug that causes fuel amount to be negative for very large ships
* adjusted armor calculation a bit more


v0.2.2

* ship archive is available now. it works similarly to the missile archive
* tooltips have been added to the ship design page
* the optimization goal slider in the ship page has been slightly redesigned to make it (hopefully) less confusing
* the default missile archive file name has been changed. existing missile archive file will be automatically renamed when launching the app.
* fixed a potential bug when loading from missile archive
* changed rounding in armor calculation, hopefully improved its accuracy


v0.2.1

* fixed a display bug on ship panel when running without a existing config file


v0.2.0

* new feature: ship optimizer
* ship optimizer maximizes available space (total space excluding engine and fuel) for a given tonnage, range and speed, while trying to matching the given tonnage
* a slider can be used to adjust the objective function of the optimizer, balancing between maximizing available space and matching desired tonnage
* this slider can be adjusted after an optimization has been performed, to update the top 100 result list
* armor calculator implemented, the value it gives may be slightly off from in game due to the difference in rounding
* jump drive and cloaking device calculator implemented
* added a calculator for tugs to find out speed and range when towing a payload
* note, the old optimizer.config file will be considered invalid, and the missile screen will restore all parameters to its default values
* to use the old optimizer.config, add a row with "MISSILE_START" in the beginning, and a row with "MISSILE_END" at the end


v0.1.3

* fixed a bug that causes index out of bound error for large missiles


v0.1.2

* fixed a bug where warhead strength is displayed incorrectly when radiation tech is available
* adjust the rounding in missile agility calculation so it should match the game better
* more logs added
* Force the jar to run in en_US locale to avoid number format issues


v0.1.1

* Slightly adjusted status bar position so it should not be hidden in half
* Force the jar to run in en_US locale if it is not already in to avoid number format issues


v0.1.0

* An earlier version implemented in EXCEL can be found at
  https://docs.google.com/spreadsheets/d/19djb0uS4AFqP94IeNRt5U_qbGrglI9Bz4iJEhcF5aRs/edit?usp=sharing
  (download as EXCEL file as it runs slowly on Google sheets)
* Currently only the missile optimizer is implemented.
* The JAVA version keeps all previous features, and added the missile archive and the possibility to share a missile design.
* The missile archive will be saved to a csv file automatically when shut down.
* Double click on alternative missile design list/missile archive list loads the selected design for viewing.
* Right click on missile archive brings up the menu to delete the selected entry.