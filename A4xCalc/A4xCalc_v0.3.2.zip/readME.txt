v0.3.2

* new feature: added the ability to import player designed components from Aurora DB in ship planner
	* it should make the ship planner easier to use with the existing components
	* read only feature, won't change the DB in any way
* a check box was added to ship planner to link deployment time and maintenance life
* a button was added to ship planner to clear the current design, and reload from ship optimizer result
* add engineering button was replaced with auto engineering button, which now is able to add and remove engineering space from the design to match the desired maintenance life
* improved the readability of the text on the progress bar in the ship planner screen
* fixed a number formatting error in the missile description
* fixed a bug where the crew and cost calculation for commercial jump drive in ship planner screen was severely wrong


v0.3.1

* fixed a bug that allows crew quarters to be manually changed under some circumstances.


v0.3.0

* new feature: ship planner
* the ship planner takes the current design displayed in the ship optimizer window, and creates an environment similar to the Class Design window in the game
* when switch to the ship planner tab, the following components will be copied from the current ship design:
	* engines
	* fuel tanks
	* armor layers if included
	* jump drive if designed
	* cloaking device if designed
* other user added components already in the ship design table will not be modified.
* 2 modes of operation: build up mode and fill up mode
* build up mode is similar to the Class Design window, where the armor and maintenance are calculated based on the current exact size
* in the fill up mode, the armor and maintenance is calculated based on the planned ship size
* double click on the component list to add a component
* double click on a component in the ship component table to remove a component
* component number in ship design can be directly edited by double clicking on the count column.
* the amount of engine, jump drive, cloaking device and crew quarters cannot be directly edited from the table
* engine, jump drive, cloaking device can be changed by editing the corresponding fields in the ship optimizer screen
* the 'add engineering spaces' button can automatically add engineering space to achieve the desired maintenance life, based on the current components on the ship. it won't remove engineering spaces to reduce maintenance life.
* player designed components can be created by clicking on the 'add new component' entries in the component list under the corresponding component category
* this is not a full Class Designer, so only the size, crew number, and cost information of the player designed components are needed.
* currently, player designed components will not be saved between sessions
* crew quarters and bridge will be automatically added as in the game
* known limitation: deployment time cannot be reduced below 1, since the known formula does not match what's in the game
* known limitation: crew quarter allocation could be slightly different (larger) compared to in game, since currently in game (1.9.5), crew quarters can be a little bit under-sized.
* known limitation: auto engineering space button may add a few more engineering space than needed
* fixed a bug that causes missile engine tech not being loaded correctly from the saved values when starting the app


v0.2.3

* fixed a bug that causes fuel amount to be negative for very large ships
* adjusted armor calculation a bit more


v0.2.2

* ship archive is available now. it works similarly to the missile archive
* tooltips have been added to the ship design page
* the optimization goal slider in the ship page has been slightly redesigned to make it (hopefully) less confusing
* the default missile archive file name has been changed. existing missile archive file will be automatically renamed when launching the app.
* fixed a potential bug when loading from missile archive
* changed rounding in armor calculation, hopefully improved its accuracy


v0.2.1

* fixed a display bug on ship panel when running without a existing config file


v0.2.0

* new feature: ship optimizer
* ship optimizer maximizes available space (total space excluding engine and fuel) for a given tonnage, range and speed, while trying to matching the given tonnage
* a slider can be used to adjust the objective function of the optimizer, balancing between maximizing available space and matching desired tonnage
* this slider can be adjusted after an optimization has been performed, to update the top 100 result list
* armor calculator implemented, the value it gives may be slightly off from in game due to the difference in rounding
* jump drive and cloaking device calculator implemented
* added a calculator for tugs to find out speed and range when towing a payload
* note, the old optimizer.config file will be considered invalid, and the missile screen will restore all parameters to its default values
* to use the old optimizer.config, add a row with "MISSILE_START" in the beginning, and a row with "MISSILE_END" at the end


v0.1.3

* fixed a bug that causes index out of bound error for large missiles


v0.1.2

* fixed a bug where warhead strength is displayed incorrectly when radiation tech is available
* adjust the rounding in missile agility calculation so it should match the game better
* more logs added
* Force the jar to run in en_US locale to avoid number format issues


v0.1.1

* Slightly adjusted status bar position so it should not be hidden in half
* Force the jar to run in en_US locale if it is not already in to avoid number format issues


v0.1.0

* An earlier version implemented in EXCEL can be found at
  https://docs.google.com/spreadsheets/d/19djb0uS4AFqP94IeNRt5U_qbGrglI9Bz4iJEhcF5aRs/edit?usp=sharing
  (download as EXCEL file as it runs slowly on Google sheets)
* Currently only the missile optimizer is implemented.
* The JAVA version keeps all previous features, and added the missile archive and the possibility to share a missile design.
* The missile archive will be saved to a csv file automatically when shut down.
* Double click on alternative missile design list/missile archive list loads the selected design for viewing.
* Right click on missile archive brings up the menu to delete the selected entry.